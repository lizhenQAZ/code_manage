print('cc')
